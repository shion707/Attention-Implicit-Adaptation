%% AA->A AA->B
clear;close all
load('Exp6_G1.mat')
trial_num=560;
subnum=13;

fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];
corrraw1=correc;

flash=tgt(:,7);
flas=flash>0.5;
noflash=flash<0.5;

fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;

rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;

dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;

abdhand=removeoutlier(abdhand,2.5);
abdhand(1:51,:)=nan;

flash=(flash-0.5)*2;
cs=flash(1:end-1).*flash(2:end);
cs=cs>0;
cs=[0; cs];

handscs=abdhand;
handscs(logical(1-cs),:)=nan;
handsic=abdhand;
handsic(logical(cs),:)=nan;
h1=nanmean(handscs);
h=nanmean(handsic);
temp=[h1 ;h];
temp1=temp;

%%
load('Exp6_G2.mat')
trial_num=560;
subnum=14;

fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];
corrraw2=correc;

flash=tgt(:,7);
flas=flash>0.5;
noflash=flash<0.5;

fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;

rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;

dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;

abdhand=removeoutlier(abdhand,2.5);
abdhand(1:51,:)=nan;

flash=(flash-0.5)*2;
cs=flash(1:end-1).*flash(2:end);
cs=cs>0;
cs=[0; cs];

handscs=abdhand;
handscs(logical(1-cs),:)=nan;
handscs=removeoutlier(handscs,2.5);

handsic=abdhand;
handsic(logical(cs),:)=nan;
handsic=removeoutlier(handsic,2.5);
h1=nanmean(handscs);
h=nanmean(handsic);
temp=[h1 ;h];
temp2=temp;

%%
load('Exp6_G3.mat')
trial_num=560;
subnum=10;

fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];
corrraw3=correc;

flash=tgt(:,7);
flas=flash>0.5;
noflash=flash<0.5;

fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;

rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;

dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;

abdhand=removeoutlier(abdhand,2.5);
abdhand(1:51,:)=nan;

flash=(flash-0.5)*2;
cs=flash(1:end-1).*flash(2:end);
cs=cs>0;
cs=[0; cs];

handscs=abdhand;
handscs(logical(1-cs),:)=nan;
handscs=removeoutlier(handscs,2.5);

handsic=abdhand;
handsic(logical(cs),:)=nan;
handsic=removeoutlier(handsic,2.5);
h1=nanmean(handscs);
h=nanmean(handsic);
temp=[h1 ;h];
temp3=temp;
%%

load('Exp6_G4.mat')
trial_num=560;
subnum=10;

fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];
corrraw4=correc;

flash=tgt(:,7);
flas=flash>0.5;
noflash=flash<0.5;

fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;

rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;

dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;

abdhand=removeoutlier(abdhand,2.5);
abdhand(1:51,:)=nan;

flash=(flash-0.5)*2;
cs=flash(1:end-1).*flash(2:end);
cs=cs>0;
cs=[0; cs];

handscs=abdhand;
handscs(logical(1-cs),:)=nan;
handscs=removeoutlier(handscs,2.5);

handsic=abdhand;
handsic(logical(cs),:)=nan;
handsic=removeoutlier(handsic,2.5);
h1=nanmean(handscs);
h=nanmean(handsic);
temp=[h1 ;h];
temp4=temp;
%%

temp=[temp1 temp2 temp3 temp4];
temp=removeoutlier(temp,2.5);
temp=removeoutlier(temp,2.5);
% f=isnan(temp(1,:));
% temp(2,f)=nan;
temp_c=temp;

corrraw=[corrraw1 corrraw2 corrraw3 corrraw4];
corrraw_c=corrraw;

c=[0 0.5 0.5];
h=mean(corrraw);
figure;
subplot(2,1,1)
hold on;

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:0.2:6);
axis([0 8 0.3 1.1])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off



figure
subplot(2,2,1);hold on
plot(temp,'color',c)%,'ShowBox',false,'ShowWhiskers',false
axis([0 3 -2 5])
set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -0.5 3.5])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off


subplot(2,2,1)
hold on;
h=temp(1,:);
%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
%plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',0.6, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
%plot(h)

scatter(0.6, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -0.5 3.5])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off

subplot(2,2,1)
hold on;
h=temp(2,:);
%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
%plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(2,h,c,2,0.2)
lineerrorbar('x',2.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
%plot(h)

scatter(2.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -0.5 3.5])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off
%%














%% AB->A AB->B

load('Exp6_G01.mat')
trial_num=560;
subnum=14;

fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];
corrraw1=correc;

flash=tgt(:,7);
flas=flash>0.5;
noflash=flash<0.5;

fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;

rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;

dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;

abdhand=removeoutlier(abdhand,2.5);
abdhand(1:51,:)=nan;

flash=(flash-0.5)*2;
cs=flash(1:end-1).*flash(2:end);
cs=cs>0;
cs=[0; cs];

handscs=abdhand;
handscs(logical(1-cs),:)=nan;
handsic=abdhand;
handsic(logical(cs),:)=nan;
h1=nanmean(handscs);
h=nanmean(handsic);
temp=[h1 ;h];
temp=removeoutlier(temp,2.5);
temp1=temp;

%%
load('Exp6_G02.mat')
trial_num=560;
subnum=11;

fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];
corrraw2=correc;

flash=tgt(:,7);
flas=flash>0.5;
noflash=flash<0.5;

fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;

rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;

dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;

abdhand=removeoutlier(abdhand,2.5);
abdhand(1:51,:)=nan;

flash=(flash-0.5)*2;
cs=flash(1:end-1).*flash(2:end);
cs=cs>0;
cs=[0; cs];

handscs=abdhand;
handscs(logical(1-cs),:)=nan;
handsic=abdhand;
handsic(logical(cs),:)=nan;
h1=nanmean(handscs);
h=nanmean(handsic);
temp=[h1 ;h];
temp=removeoutlier(temp,2.5);
temp2=temp;

%%
load('Exp6_G03.mat')
trial_num=560;
subnum=14;

fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];
corrraw3=correc;

flash=tgt(:,7);
flas=flash>0.5;
noflash=flash<0.5;

fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;

rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;

dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;

abdhand=removeoutlier(abdhand,2.5);
abdhand(1:51,:)=nan;

flash=(flash-0.5)*2;
cs=flash(1:end-1).*flash(2:end);
cs=cs>0;
cs=[0; cs];

handscs=abdhand;
handscs(logical(1-cs),:)=nan;
handsic=abdhand;
handsic(logical(cs),:)=nan;
h1=nanmean(handscs);
h=nanmean(handsic);
temp=[h1 ;h];
temp=removeoutlier(temp,2.5);
temp3=temp;

%%
temp=[temp1 temp2 temp3];
temp=removeoutlier(temp,2.5);
f=isnan(temp(2,:));
temp(1,f)=nan;
f=isnan(temp(1,:));
temp(2,f)=nan;
temp_i=temp;
corrraw=[corrraw1 corrraw2 corrraw3];

c=[0 0.7 0.7];
h=mean(corrraw);
figure;
subplot(2,1,1)
hold on;

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:0.2:6);
axis([0 8 0.3 1.1])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off



figure
subplot(2,2,1);hold on
plot(temp,'color',c)%,'ShowBox',false,'ShowWhiskers',false
axis([0 3 -2 5])
set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -0.5 3.5])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off


subplot(2,2,1)
hold on;
h=temp(1,:);
%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
%plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',0.6, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
%plot(h)

scatter(0.6, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -0.5 3.5])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off

subplot(2,2,1)
hold on;
h=temp(2,:);
%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
%plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(2,h,c,2,0.2)
lineerrorbar('x',2.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
%plot(h)

scatter(2.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -0.5 3.5])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off

save('Exp6_r.mat','corrraw','corrraw_c','temp_i','temp_c')
%% MIX ANOVA
%group: AA vs AB
%condition: A>A vs A>B

score = [temp_c(:); temp_i(:)]';
subject = [1:length(score)/2;1:length(score)/2];
subject=subject(:)';
condition = repmat([1 2], 1, length(score)/2);
group = [ones(1,length(temp_c)*2) 2*ones(1,length(temp_i)*2)];


% Create a table from the data
data = table(subject', condition', group', score', 'VariableNames', {'Subject', 'Condition', 'Group', 'Score'});

% Fit a mixed-effects model (MIXED-ANOVA)
mixedModel = fitglme(data, 'Score ~ Condition * Group + (1|Subject)');

% Perform mixed-design ANOVA using the fitglme model
anovaResults = anova(mixedModel);

disp(anovaResults)
% Display the ANOVA results

%% POSTHOC
%AA->A temp_c(1,:)
%AA->B temp_c(2,:)
%AB->B temp_c(3,:)
%AB->A temp_c(4,:)

[a b c d]=ttest2(temp_i(1,:),temp_c(2,:))
[a b c d]=ttest(temp_i(1,:),temp_i(2,:))
[a b c d]=ttest2(temp_i(2,:),temp_c(2,:))
d = computeCohen_d(temp_i(1,:),temp_i(2,:))
[bf10,pValue] = bf.ttest2(temp_i(1,:),temp_c(2,:));

% [a b c d]=ttest2(temp_i(1,:),temp_c(1,:))
% [a b c d]=ttest2(temp_i(2,:),temp_c(2,:))
% [a b c d]=ttest(temp_i(1,:),temp_i(2,:))
% 
% [bf10,pValue] = bf.ttest2(temp_i(2,:),temp_c(2,:));
% [bf10,pValue] = bf.ttest(temp_i(2,:),temp_i(1,:));
% 
% d = computeCohen_d(temp_c(1,:),temp_c(2,:),'paired')
% 
% 
% d = computeCohen_d(temp_c(2,:),temp_i(2,:))
















