%% Exp 3: single condition
clear;close all
load('Exp3sin_data.mat')
trial_num=560;
subnum=33;
bin_num=1;
subnumall=subnum;

%%
% remove participants with low acc and low valid trial
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];

%%
fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;
rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;
dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];
ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;
abdhand=removeoutlier(abdhand,2.5);
abdhand=abdhand(51:end,:);
nofbhand=removeoutlier(nofbhand,2.5);
nofbhand=nofbhand(51:end,:);
abh1=nanmean(abdhand);
h=[abh1];
h = removeoutlier(h,2.5);


c=[0.5 0.5 0.5];
subplot(2,2,2)
hold on;

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 0 3.7])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off

h_con=h;

%%







%% 0-back
load('Exp3_0b_data.mat')
subnum=35;


c=[0.3 0.5 0.8];
figure;
h=mean(correc);
corrraw=correc;
subplot(2,2,1)
hold on;

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:0.2:6);
axis([0 4 0.3 1.1])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off

%%
fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];

%%
fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;
rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;
dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];
ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;
abdhand=removeoutlier(abdhand,2.5);
abdhand=abdhand(51:end,:);
nofbhand=removeoutlier(nofbhand,2.5);
nofbhand=nofbhand(51:end,:);
abh1=nanmean(abdhand);
h=[abh1];
h = removeoutlier(h,2.5);


subplot(2,2,2)
hold on;

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 0 3.7])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off

h_0b=h;

save('Exp3_0b_r.mat','corrraw','h')
%%












%% 1-back condition
load('Exp3_1b_data.mat')
subnum=56;


c=[0.5 0.8 1];
figure;
h=mean(correc);
corrraw=correc;
subplot(2,2,1)
hold on;

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:0.2:6);
axis([0 4 0.3 1.1])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off

%%
fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];

%%
fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;
rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;
dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];
ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;
abdhand=removeoutlier(abdhand,2.5);
abdhand=abdhand(51:end,:);
nofbhand=removeoutlier(nofbhand,2.5);
nofbhand=nofbhand(51:end,:);
abh1=nanmean(abdhand);
h=[abh1];
h = removeoutlier(h,2.5);


subplot(2,2,2)
hold on;

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 0 3.7])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off
save('Exp3_1b_r.mat','corrraw','h')
%%
% stats
[a b c stats]=ttest2(h, h_con)
[bf10,pValue] = bf.ttest2(h, h_con)
d = computeCohen_d(h, h_con)

[a b c stats]=ttest2(h_0b, h_con)
[bf10,pValue] = bf.ttest2(h_0b, h_con)
d = computeCohen_d(h_0b, h_con)

[a b c stats]=ttest2(h_0b, h)
[bf10,pValue] = bf.ttest2(h_0b, h)
d = computeCohen_d(h_0b, h)