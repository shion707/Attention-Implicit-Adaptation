clear;close all
load('Exp1d_data.mat')

trial_num=560;
subnum=99;
bin_num=1;

subnumall=subnum;


c=[0.3 0.7 0.8];  
figure;
h=mean(correc);
subplot(2,3,1)
hold on;

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:0.2:6);
axis([0 4 0.3 1.1])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off

%%


badbl=[];%
% badbl=[ ];
fbad=find(mean(correc)<0.7);
lefth=[];
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[badbl lefth f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];

subnum=subnum-length(badsubject);
correc(:,badsubject)=[];

%%
correc=correc;
correc=correc(21:end,:);
rotationdeg=rotation(1:trial_num);

cue=[];
for i=1:trial_num
    if tgt(i,1)==1
        if rotationdeg(i)>0
            cue(i)=0;
        elseif rotationdeg(i)<0
            cue(i)=1;
        end
    elseif tgt(i,1)==2
        if rotationdeg(i)>0
            cue(i)=1;
         elseif rotationdeg(i)<0
            cue(i)=0;
        end
    end
end
cue=cue(41:end);


mean(correc)


hand_common_bin_angle(561,:)=nan;
dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

% ccw=(rotationdeg>0);
% cw=(rotationdeg<0);

ccw=(tgt(:,1)==2);
cw=(tgt(:,1)==1);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
abdhand=removeoutlier(abdhand,3);
abdhand=abdhand(41:end,:);

% abdhandbl=dhand;
% ccw=(tgt(:,1)==2);
% abdhandbl(ccw,:)=-dhand(ccw,:);
% abdhandbl=abdhandbl(41:end,:);
baseline=find(tgt(41:end,5)==0);
blhand=nanmedian(abdhand(baseline,:));
abdhand(baseline,:)=nan;

cued=find(cue>-100);
uncued=find(cue==0);

cuehand=nanmedian(abdhand(cued,:));
uncuehand=nanmedian(abdhand(uncued,:));
allhand=nanmedian(abdhand(:,:));
%%

lear=[cuehand; uncuehand; blhand];

subplot(2,2,3)
hold on;
h=cuehand-uncuehand;

plot([-100 100],[0,0],'k-')

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',2,'color',c);
scatter(1.5, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-100:100);
axis([0 4 -2 2])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
hcross=h;
box off

alltril=cuehand-uncuehand;

[a b c stats]=ttest(alltril)

t_stat = stats.tstat;
df = stats.df;

% Calculate eta squared
eta_squared = (t_stat^2) / (t_stat^2 + df)

[bf10,pValue] = bf.ttest(alltril)
d = computeCohen_d(cuehand,uncuehand, 'paired')