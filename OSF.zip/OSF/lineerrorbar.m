function result=lineerrorbar(varargin) 
    param= inputParser;   
    param.addParameter('x', 1);   
    param.addParameter('y', 1); 
    param.addParameter('std', 1); 
    param.addParameter('color', 'k'); 
    param.addParameter('width', 1); 
    param.addParameter('subnum', 1); 
    param.parse(varargin{:});
    x=param.Results.x;
    y=param.Results.y;
    sd=param.Results.std;
    co=param.Results.color;
    w=param.Results.width;
    subnum=param.Results.subnum;
    
    se=sd./sqrt(subnum);
    for i=1:length(x)
    plot([x(i) x(i)],[y(i)+se(i) y(i)-se(i)],'linewidth',w,'color',co)
    end
    
    result=param.Results;
end

    