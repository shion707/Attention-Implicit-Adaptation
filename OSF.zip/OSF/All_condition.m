%% Rank all conditions 
% correlation between accuracy and learning rate

clear;clc; close all
hand=[];
acc=[];


c=[0.5 0.8 0.8];
load("Exp1a_r")
ac=nanmean(nanmean(corrraw(50:end,:)));
x=ac;
h=nanmean(h(1:2,:));

figure(111)
hold on;
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(x, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h)];
acc=[acc,ac];

figure(222)
c=[1,1,1]
hold on;
x=1;
bar(x,nanmean(h),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color','k');

alldata(x,:)=[nanmean(h) nanstd(h)./sqrt(sum(h>-100)-1)];

%%

figure(111)
c=[0.3 0.6+0.1 0.8];
load("Exp1c_r")
h=nanmean(h(1:2,:));
ac=nanmean(nanmean(corrraw(50:end,:)));
x=ac;
hold on;
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(x, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h)];
acc=[acc,ac];


figure(222)
c=[1,1,1]
hold on;
x=2;
bar(x,nanmean(h),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color','k');
alldata(x,:)=[nanmean(h) nanstd(h)./sqrt(sum(h>-100)-1)];

%%

figure(111)
c=[0.8 0.3 1];
load("Exp2_r")
ac=nanmean(nanmean(corrraw(50:end,:)));
x=ac;
hold on;
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(x, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h)];
acc=[acc,ac];

figure(222)
c=[1,1,1]
hold on;
x=3;
bar(x,nanmean(h),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color','k');
alldata(x,:)=[nanmean(h) nanstd(h)./sqrt(sum(h>-100)-1)];
%%


figure(111)
c=[0.3 0.5 0.8];
load("Exp3_0b_r")
ac=nanmean(nanmean(corrraw(50:end,:)));
x=ac;
hold on;
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(x, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h)];
acc=[acc,ac];


figure(222)
c=[1,1,1]
hold on;
x=4;
bar(x,nanmean(h),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color','k');
alldata(x,:)=[nanmean(h) nanstd(h)./sqrt(sum(h>-100)-1)];

%%

figure(111)
c=[0.5 0.8 1];
load("Exp3_1b_r")
ac=nanmean(nanmean(corrraw(50:end,:)));
x=ac;
hold on;
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(x, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h)];
acc=[acc,ac];

figure(222)
c=[1,1,1]
hold on;
x=5;
bar(x,nanmean(h),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color','k');
alldata(x,:)=[nanmean(h) nanstd(h)./sqrt(sum(h>-100)-1)];

%%

figure(111)
c=[0.9 0.8 0.2];
load("Exp4_r")
ac=nanmean(nanmean(corrraw(50:end,:)));
x=ac;
hold on;
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(x, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h)];
acc=[acc,ac];

figure(222)
c=[1,1,1]
hold on;
x=6;
bar(x,nanmean(h),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color','k');

alldata(x,:)=[nanmean(h) nanstd(h)./sqrt(sum(h>-100)-1)];



%%
figure(111)


load("Exp5_r.mat")
c=[0.5 0.5 1];
ac=nanmean(nanmean(corrraw(50:end,:)));
x=ac;
hold on;
lineerrorbar('x',x, 'y', nanmean(h(1,:)),'std', nanstd(h(1,:)),'subnum',sum(h(1,:)>-100),'width',2,'color',c);
scatter(x, nanmean(h(1,:)),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h(1,:))];
acc=[acc,ac];

lineerrorbar('x',x, 'y', nanmean(h(2,:)),'std', nanstd(h(2,:)),'subnum',sum(h(1,:)>-100),'width',2,'color',c);
scatter(x, nanmean(h(2,:)),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h(2,:))];
acc=[acc,ac];


figure(222)
c=[1,1,1];
hold on;
x=7;
bar(x,nanmean(h(1,:)),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h(1,:)),'std', nanstd(h(1,:)),'subnum',sum(h(1,:)>-100),'width',2,'color','k');
alldata(x,:)=[nanmean(h(1,:)) nanstd(h(1,:))./sqrt(sum(h(1,:)>-100)-1)];

x=8;
bar(x,nanmean(h(2,:)),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h(2,:)),'std', nanstd(h(2,:)),'subnum',sum(h(2,:)>-100),'width',2,'color','k');
alldata(x,:)=[nanmean(h(2,:)) nanstd(h(2,:))./sqrt(sum(h(2,:)>-100)-1)];

%%

figure(111)
load('Exp6_r.mat')
h=temp_c;
ac=nanmean(nanmean(corrraw_c(50:end,:)));
x=ac;
c=[0 0.5 0.5]

lineerrorbar('x',x, 'y', nanmean(h(1,:)),'std', nanstd(h(1,:)),'subnum',sum(h(1,:)>-100),'width',2,'color',c);
scatter(x, nanmean(h(1,:)),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h(1,:))];
acc=[acc,ac];
lineerrorbar('x',x, 'y', nanmean(h(2,:)),'std', nanstd(h(2,:)),'subnum',sum(h(1,:)>-100),'width',2,'color',c);
scatter(x, nanmean(h(2,:)),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h(2,:))];
acc=[acc,ac];

figure(222)
c=[1,1,1]
hold on;
x=9;
bar(x,nanmean(h(1,:)),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h(1,:)),'std', nanstd(h(1,:)),'subnum',sum(h(1,:)>-100),'width',2,'color','k');
alldata(x,:)=[nanmean(h(1,:)) nanstd(h(1,:))./sqrt(sum(h(1,:)>-100)-1)];

x=10;
bar(x,nanmean(h(2,:)),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h(2,:)),'std', nanstd(h(2,:)),'subnum',sum(h(2,:)>-100),'width',2,'color','k');
alldata(x,:)=[nanmean(h(2,:)) nanstd(h(2,:))./sqrt(sum(h(1,:)>-100)-1)];

%%
figure(111)

load('Exp6_r.mat')
h=temp_i;
ac=nanmean(nanmean(corrraw(50:end,:)));
x=ac;
c=[0 0.7 0.7]

lineerrorbar('x',x, 'y', nanmean(h(1,:)),'std', nanstd(h(1,:)),'subnum',sum(h(1,:)>-100),'width',2,'color',c);
scatter(x, nanmean(h(1,:)),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h(1,:))];
acc=[acc,ac];
lineerrorbar('x',x, 'y', nanmean(h(2,:)),'std', nanstd(h(2,:)),'subnum',sum(h(1,:)>-100),'width',2,'color',c);
scatter(x, nanmean(h(2,:)),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
hand=[hand,nanmean(h(2,:))];
acc=[acc,ac];


set(gca,'xtick',0:0.1:1);
set(gca,'ytick',-1:0.5:4);
axis([0.61 1.05 0 2])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off


figure(222)
c=[1,1,1]
hold on;
x=11;
bar(x,nanmean(h(1,:)),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h(1,:)),'std', nanstd(h(1,:)),'subnum',sum(h(1,:)>-100),'width',2,'color','k');
alldata(x,:)=[nanmean(h(1,:)) nanstd(h(1,:))./sqrt(sum(h(1,:)>-100)-1)];

x=12;
bar(x,nanmean(h(2,:)),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',x, 'y', nanmean(h(2,:)),'std', nanstd(h(2,:)),'subnum',sum(h(2,:)>-100),'width',2,'color','k');
set(gca,'xtick',[1:100]);
set(gca,'ytick',-1:0.5:4);
axis([0 18 0 2])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off
alldata(x,:)=[nanmean(h(2,:)) nanstd(h(2,:))./sqrt(sum(h(2,:)>-100)-1)];



%%
[s ss]=sort(alldata(:,1));
ss=ss(end:-1:1);
m=0;
c=[1,1,1];
figure(223);
subplot(2,1,1);hold on;
for b=1:12
k=ss(b);
bar(b,alldata(k,1),'facecolor',c,'facealpha',1,'linewidth',2);
lineerrorbar('x',b, 'y', alldata(k,1),'std', alldata(k,2),'subnum',1,'width',2,'color','k');

end
set(gca,'xtick',[1:100]);
set(gca,'ytick',-1:0.5:4);
axis([0 18 0 2])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off


l=(alldata(:,1));
lr(1:6)=l(1:6);
lr(7)=(l(7)+l(8))/2;
lr(8)=(l(9)+l(10))/2;
lr(9)=(l(11)+l(12))/2;

ac(1:7)=acc(1:7);
ac(8)=acc(10);
ac(9)=acc(11);

[r,p]=corrcoef(ac',lr);
modl=fitlm(ac',lr);
figure(111)
plot(modl)