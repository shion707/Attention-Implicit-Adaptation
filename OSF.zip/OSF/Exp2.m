%% Exp 2: Dual condition
clear;close all
load('Exp2dual_data.mat')
trial_num=560;
subnum=33;
bin_num=1;

subnumall=subnum;

%%
c=[0.8 0.3 1];
figure;
corrraw=correc;
h=mean(correc);
subplot(2,2,1)
hold on;

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)

set(gca,'xtick',[]);
set(gca,'ytick',-1:0.2:6);
axis([0 4 0.3 1.1])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off
%%
% remove participants with low acc and low valid trial
fbad=find(mean(correc)<0.7);
lefth=[];
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[lefth f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];

%%
fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;
rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;
dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];
ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;
abdhand=removeoutlier(abdhand,2.5);
abdhand=abdhand(51:end,:);
nofbhand=removeoutlier(nofbhand,2.5);
nofbhand=nofbhand(51:end,:);
abh1=nanmean(abdhand);
h=[abh1];
h = removeoutlier(h,2.5);


c=[0.8 0.3 1];
subplot(2,2,2)
hold on;

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -1 3.7])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off
h_dual=h;
save('Exp2_r.mat','corrraw','h')

%%












%% Exp 2: single condition
load('Exp2Sin_data.mat')
trial_num=560;
subnum=30;
bin_num=1;
subnumall=subnum;

%%
fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;
rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;
dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;
abdhand=removeoutlier(abdhand,3);
abdhand=abdhand(51:end,:);
nofbhand=removeoutlier(nofbhand,3);
nofbhand=nofbhand(51:end,:);
abh1=nanmean(abdhand);
h=[abh1];

c=[0.5 0.5 0.5];
figure;
subplot(2,2,1)
hold on;

plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -1 3.7])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off

%%
% stats

[a b c stats]=ttest2(h_dual, abh1)

[bf10,pValue] = bf.ttest2(h_dual,abh1)
d = computeCohen_d(h_dual,abh1)
