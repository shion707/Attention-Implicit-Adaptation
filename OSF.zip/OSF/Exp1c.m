clear;close all
load('Exp1c_data.mat')
trial_num=560;
subnum=90;
bin_num=1;

%% Accuracy
corrraw=correc;
rt_bin(rt_bin>2000)=nan;
c=[0.3 0.7 0.8]; 

figure(111);
h=mean(correc);
subplot(2,3,1)
hold on;
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)

set(gca,'xtick',[]);
set(gca,'ytick',-1:0.2:6);
axis([0 2 0.3 1.1])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
title('accuracy');
box off
%%
% remove participants with low acc and low valid trial
fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];

%%
rotationdeg=rotation(1:trial_num);

cue=[];
for i=1:trial_num
    if tgt(i,1)==1
        if rotationdeg(i)>0
            cue(i)=0;
        elseif rotationdeg(i)<0
            cue(i)=1;
        end
    elseif tgt(i,1)==2
        if rotationdeg(i)>0
            cue(i)=1;
         elseif rotationdeg(i)<0
            cue(i)=0;
        end
    end
end
cue=cue(41:end);

hand_common_bin_angle(561,:)=nan;
dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
abdhand=removeoutlier(abdhand,3);
abdhand=abdhand(41:end,:);

abdhandbl=dhand;
ccw=(tgt(:,1)==2);
abdhandbl(ccw,:)=-dhand(ccw,:);
abdhandbl=abdhandbl(41:end,:);
baseline=find(tgt(41:end,5)==0);
blhand=nanmedian(abdhandbl(baseline,:));
abdhand(baseline,:)=nan;

cued=find(cue==1);
uncued=find(cue==0);

cuehand=nanmedian(abdhand(cued,:));
uncuehand=nanmedian(abdhand(uncued,:));
allhand=nanmedian(abdhand(:,:));

%%
corr=corrraw;
corr=corr(41:end,:);
blAcc=nanmean(corr(baseline,:));
corr(baseline,:)=nan;
cueAcc=nanmean(corr(cued,:));
cunueAcc=nanmean(corr(uncued,:));
lear=[cueAcc; cunueAcc;blAcc];

c=[0.3 0.7 0.8];  
subplot(2,3,2);hold on
plot(lear,'linewidth',0.5,'color',[0.9 0.9 0.9],'linewidth',1)
errorbar(nanmedian(lear'),nanstd(lear')/sqrt(subnum),'color',c,'linewidth',2)
[a b c d]=ttest(cueAcc, cunueAcc);
set(gca,'xtick',[]);
axis([0 4 0.3 1.1])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
set(gca,'xtick',[1 2 3]);
set(gca,'xticklabel',{'cue','uncue','NoFB'});
box off
%%

lear=[cuehand; uncuehand; blhand];
lear=removeoutlier(lear,2.5);

subplot(2,3,3)
hold on;
h=lear;
plot(lear,'b','linewidth',0.5,'color',[0.9 0.9 0.9],'linewidth',1)
plot([-100 100],[0,0],'k-')
for i=[1:3]
c=[0.3 0.6+0.1*i 0.8];  
realboxplot(i,h(i,:),c,2,0.2)
lineerrorbar('x',i+0.4, 'y', nanmean(h(i,:)),'std', nanstd(h(i,:)),'subnum',length(h),'width',2,'color',c);
scatter(i+0.4, nanmean(h(i,:)),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
end
set(gca,'xtick',[1 2 3]);
set(gca,'xticklabel',{'cue','uncue','NoFB'});
axis([0 4 -2 3])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
hcross=h;
box off
save('Exp1c_r.mat','corrraw','h')

%%
%STATS
alltril=cuehand-uncuehand;
[a b c stats]=ttest(alltril);
t_stat = stats.tstat;
df = stats.df;
% Calculate eta squared
eta_squared = (t_stat^2) / (t_stat^2 + df);
[bf10,pValue] = bf.ttest(alltril)
d = computeCohen_d(cuehand,uncuehand, 'paired')

