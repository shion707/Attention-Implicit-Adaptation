clear;close all
load('Exp2Sin_data.mat')
trial_num=560;
subnum=30;
bin_num=1;
subnumall=subnum;

%%
fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;
rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;
dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;
abdhand=removeoutlier(abdhand,3);
abdhand=abdhand(51:end,:);
nofbhand=removeoutlier(nofbhand,3);
nofbhand=nofbhand(51:end,:);
abh1=nanmean(abdhand);
h=[abh1];

c=[0.5 0.5 0.5];
figure;
subplot(2,2,1)
hold on;

plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -1 3.7])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off
%%
% stats
load('Exp2_dual_result.mat')
[a b c stats]=ttest2(h, abh1)

[bf10,pValue] = bf.ttest2(h,abh1)
d = computeCohen_d(h,abh1)
