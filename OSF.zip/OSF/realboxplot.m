function h = realboxplot(x0,h,c,l,w)

qu1=quantile(h,0.25);
qu2=quantile(h,0.75);
x=[x0+w,x0+w,x0-w,x0-w];
y=[qu1,qu2,qu2,qu1];
h=removeoutlier(h,3);
plot([x0 x0],[max(h),qu2],'k-','linewidth',l,'color',c);
plot([x0 x0],[min(h),qu1],'k-','linewidth',l,'color',c);
patch(x,y,c,'linewidth',l,'edgecolor',c,'FaceColor','none')

se=nanstd(h)./sqrt(sum(h>-1000000000));
plot([x0+w,x0-w],[nanmedian(h),nanmedian(h)],'k-','linewidth',l,'color',c)
%patch([x0+0.3*w,x0+0.3*w,x0-0.3*w,x0-0.3*w],[nanmean(h)+se nanmean(h)-se nanmean(h)-se nanmean(h)+se],c,'edgecolor','none')

%scatter(x0, nanmedian(h),50,'markerfacecolor',[1 1 1],'markerfacealpha',1,'markeredgecolor','k','linewidth',1)
end