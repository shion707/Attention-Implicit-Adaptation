clear;close all
%%
load('Exp5.mat')
trial_num=560;
subnum=11;
bin_num=1;
subnumall=subnum;
%%

fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];
corrraw=correc;

%%
flash=tgt(:,7);
flas=flash>0.5;
noflash=flash<0.5;

fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;

rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;

dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;

abdhand=removeoutlier(abdhand,2.5);
abdhand(1:11,:)=nan;

handscs=abdhand;
handscs(logical(1-flas),:)=nan;
handscs=removeoutlier(handscs,2.5);

handsic=abdhand;
handsic(logical(flas),:)=nan;
handsic=removeoutlier(handsic,2.5);

h1=nanmean(handscs);
h=nanmean(handsic);

temp=[h1 ;h];
temp0=temp;

%%
load('Exp5_G2.mat')
trial_num=560;
subnum=14;
bin_num=1;
subnumall=subnum;
%%

fbad=find(mean(correc)<0.7);
f=find(nanmean(hand_common_bin_angle<100)<0.7);
badsubject=[f fbad];
badsubject=unique(badsubject);
hand_common_bin_angle(:,badsubject)=[];
mt_bin(:,badsubject)=[];
rt_bin(:,badsubject)=[];
subnum=subnum-length(badsubject);
correc(:,badsubject)=[];
corrraw2=correc;

%%
flash=tgt(:,7);
flas=flash>0.5;
noflash=flash<0.5;

fb=tgt(:,5);
nofb=fb<0.5;
yesfb=fb>0.5;

rotationdeg=rotation(1:560);
hand_common_bin_angle(561:566,:)=nan;

dhand=hand_common_bin_angle(2:561,:)-hand_common_bin_angle(1:560,:);
abdhand=[];

ccw=(rotationdeg>0);
cw=(rotationdeg<0);
abdhand(ccw,:)=-dhand(ccw,:);
abdhand(cw,:)=dhand(cw,:);
nofbhand=abdhand(nofb,:);
abdhand(nofb,:)=nan;

abdhand=removeoutlier(abdhand,2.5);
abdhand(1:11,:)=nan;

handscs=abdhand;
handscs(logical(1-flas),:)=nan;
handscs=removeoutlier(handscs,2.5);

handsic=abdhand;
handsic(logical(flas),:)=nan;
handsic=removeoutlier(handsic,2.5);

h1=nanmean(handscs);
h=nanmean(handsic);

temp=[h1 ;h];
%%

tem1=temp0(1,:);
tem2=temp0(2,:);
tem3=temp(1,:);
tem4=temp(2,:);

tcon=[tem1 tem4];
tfls=[tem2 tem3];

tfls=removeoutlier(tfls,2.5);
tcon=removeoutlier(tcon,2.5);

corrraw=[corrraw corrraw2];

figure;
hold on;
c=[0.5 0.5 1];
%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);

h=corrraw;
figure;
h=mean(corrraw);
subplot(2,1,1)
hold on;

%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',1.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100),'width',2,'color',c);
scatter(1.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:0.2:6);
axis([0 8 0.3 1.1])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off

figure
h=tcon;
subplot(2,2,1)
hold on;
c=[0.5 0.5 0.7];
%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
%plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(1,h,c,2,0.2)
lineerrorbar('x',0.6, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100)-2,'width',2,'color',c);
scatter(0.6, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -1 3.7])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off



h=tfls;
subplot(2,2,1)
hold on;
%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);
%plotSpread(h','categoryIdx',ones(length(h),1),'distributionMarkers',{'o'},'distributioncolor',{num2str(c)})
realboxplot(2,h,c,2,0.2)
lineerrorbar('x',2.4, 'y', nanmean(h),'std', nanstd(h),'subnum',sum(h>-100)-2,'width',2,'color',c);
scatter(2.4, nanmean(h),20,'markerfacecolor',c,'markerfacealpha',1,'markeredgecolor',c,'linewidth',2)
%plot([0.9 1.1], [nanmean(h) nanmean(h)],'k-','linewidth',0.7,'color',[0.5,0,0])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -1 3.7])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off

h=[tcon; tfls];
subplot(2,2,1)
hold on;
%lineerrorbar('x',1.5, 'y', nanmean(h),'std', nanstd(h),'subnum',length(h),'width',0.1,'widthbox', 0.2,'color',[1,0.1,0.1]);


plot(h, 'k-','linewidth',0.5,'color',[0.5,0.5,1])
%scatter(1+randn(1,length(h))*0.1,h,10,'markerfacecolor',[1,0.5,0.5],'markerfacealpha',0.3,'markeredgecolor','none','linewidth',0.7)

set(gca,'xtick',[]);
set(gca,'ytick',-1:6);
axis([0 4 -1 3.7])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
set(gca, 'LineWidth',0.5);
box off
save('Exp5_r.mat','corrraw','h')
%%
%stats
[a b c d]=ttest(tcon-tfls)
[bf10,pValue] = bf.ttest(tcon,tfls)
d = computeCohen_d(tcon,tfls,'paired')

